<!-- Back Top top -->
        <div class="back-to-top">Top</div>
        <!-- End Back Top top -->

        <!-- jQuery Min JS -->
        <script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/jquery-3.2.1.slim.min.js"></script>
        <!-- Popper Min JS -->
        <script src="assets/js/popper.min.js"></script>
        <!-- Bootstrap Min JS -->
        <script src="assets/js/bootstrap.min.js"></script>
        <!-- Ui JS -->
        <script src="assets/js/jquery-ui.min.js"></script>
        <!-- Slick Min JS -->
        <script src="assets/js/slick.min.js"></script>
        <!-- Mean Menu Min JS -->
        <script src="assets/js/jquery.meanmenu.js"></script>
        <!-- Magnific Min JS -->
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
        <!-- Mixitup Min JS -->
        <script src="assets/js/jquery.mixitup.min.js"></script>
        <!-- Owl Carousel Min JS -->
        <script src="assets/js/owl.carousel.min.js"></script>
        <!-- Nice Select Min JS -->
        <script src="assets/js/jquery.nice-select.min.js"></script>
        <!-- Counterup JS -->
        <script src="assets/js/jquery.counterup.min.js"></script>
        <!-- Waypoints Min JS -->
        <script src="assets/js/waypoints.min.js"></script>
        <!-- Form Ajaxchimp JS -->
		<script src="assets/js/jquery.ajaxchimp.min.js"></script>
        <!-- Form Validator JS -->
		<script src="assets/js/form-validator.min.js"></script>
		<!-- Contact JS -->
		<script src="assets/js/contact-form-script.js"></script>
        <!-- Active JS -->
        <script src="assets/js/active.js"></script>